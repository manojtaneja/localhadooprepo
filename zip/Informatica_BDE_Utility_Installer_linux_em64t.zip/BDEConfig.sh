. ./Messages/common.msg
. ./properties/version.txt

validateIBMJavaVersion()
{
	java_major=`echo $JAVA_MAJOR | sed 's/\./\\\./g'`
	printf "$VALIDATE_JAVA"
    echo "INFA_JDK_HOME=$INFA_JDK_HOME" > "$2/java_version.txt"
    echo `$1/jre/bin/java -version 2>> "$2/java_version.txt"`
	if grep -q $java_major "$2/java_version.txt"; then
		printf "$VALID_JAVA_MAJOR_VER" $JAVA_MAJOR
		if grep -q $JAVA_MINOR "$2/java_version.txt"; then
			printf "$VALID_JAVA_SUB_VER" $JAVA_MINOR
			export PATH=$INFA_JDK_HOME/jre/bin:$PATH
		else
			printf "$INVALID_JAVA_SUB_VER" $JAVA_MINOR
			printf "$EXIT"
			exit
		fi
	else
		printf "$INVALID_JAVA_MAJOR_VER" $JAVA_MAJOR $JAVA_MINOR
		printf "$EXIT"
		exit
	fi
}

checkAIX()
{
pdir=`pwd`
printf "$VALIDATE_INFA_JDK_HOME"
if [ $INFA_JDK_HOME ]
then
	if [ -d $INFA_JDK_HOME/jre/bin ]
	then
       	printf "$VALID_PATH"
		validateIBMJavaVersion $INFA_JDK_HOME $pdir
	else
		printf "$INVALID_PATH"
		exit
	fi
else
	printf "$ERROR_MSG"
	exit
fi
}


validateHPUXJavaVersion()
{
	java_major=`echo $JAVA_MAJOR | sed 's/\./\\\./g'`
	printf "$VALIDATE_JAVA"
    echo "INFA_JDK_HOME=$INFA_JDK_HOME" > "$2/java_version.txt"
    echo `$1/jre/bin/java -version 2>> "$2/java_version.txt"`
	if grep -q $java_major "$2/java_version.txt"; then
		printf "$VALID_JAVA_MAJOR_VER" $JAVA_MAJOR
		export PATH=$INFA_JDK_HOME/jre/bin:$PATH
	else
		printf "$INVALID_HP_JAVA_VER" $JAVA_MAJOR
		printf "$EXIT"
		exit
	fi
}

checkHPUX()
{
pdir=`pwd`
printf "$VALIDATE_INFA_JDK_HOME"
if [ $INFA_JDK_HOME ]
then
	if [ -d $INFA_JDK_HOME/jre/bin ]
	then
       	printf "$VALID_PATH"
		validateHPUXJavaVersion $INFA_JDK_HOME $pdir
	else
		printf "$INVALID_PATH"
		exit
	fi
else
	printf "$ERROR_MSG"
	exit
fi
}



validateZLinuxJavaVersion()
{
	java_major=`echo $JAVA_MAJOR | sed 's/\./\\\./g'`
	printf "$VALIDATE_JAVA"
    echo "INFA_JDK_HOME=$INFA_JDK_HOME" > "$2/java_version.txt"
    echo `$1/jre/bin/java -version 2>> "$2/java_version.txt"`
	if grep -q $java_major "$2/java_version.txt"; then
		printf "$VALID_JAVA_MAJOR_VER" $JAVA_MAJOR
		if grep -q $JAVA_MINOR "$2/java_version.txt"; then
			printf "$VALID_JAVA_SUB_VER" $JAVA_MINOR
			export PATH=$INFA_JDK_HOME/jre/bin:$PATH
		else
			printf "$INVALID_JAVA_SUB_VER" $JAVA_MINOR
			printf "$EXIT"
			exit
		fi
	else
		printf "$INVALID_JAVA_MAJOR_VER" $JAVA_MAJOR $JAVA_MINOR
		printf "$EXIT"
		exit
	fi
}

checkZLin()
{
pdir=`pwd`
printf "$VALIDATE_INFA_JDK_HOME"
if [ $INFA_JDK_HOME ]
then
	if [ -d $INFA_JDK_HOME/jre/bin ]
	then
        printf "$VALID_PATH"
		validateZLinuxJavaVersion $INFA_JDK_HOME $pdir
	else
		printf "$INVALID_PATH"
		exit
	fi
else
	printf "$ERROR_MSG"
	exit
fi
}

checkINFA_JDK_HOME()
{
	OSTYPE=`uname -s`
	architecture=`uname -m`
	if [ $OSTYPE = "HP-UX" ] || [ $OSTYPE = "AIX" ] || [ $architecture = "s390x" ]
	then
		if [ $INFA_JDK_HOME ]
		then
			if [ -d $INFA_JDK_HOME/jre/bin ]
			then
				printf "$VALID_PATH"
			else
				printf "$INVALID_PATH"
				exit
			fi
		else
			printf "$ERROR_MSG"
			exit
		fi
	fi
}
checkOSType()
{
	OSTYPE=`uname -s`
	architecture=`uname -m`
	if [ $OSTYPE = "HP-UX" ]
	then
	#HP-UX
	checkHPUX
	elif [ $OSTYPE = "AIX" ]
	then
	#AIX
	checkAIX
	elif [ $architecture = "s390x" ]
	then
	# zLinux
	checkZLin
fi
}


checkOSType
chmod -R 755 ./properties
cd Server
if [ -f installer.properties ]
then
rm -rf installer.properties
fi
sh install.bin -i silent
