	
# SSH/SCP connection copy - A script to connect to cluster

##### Constants

CONNECTORCOPY=$1
HOSTNAME=$2
USERNAME=$3
PASSWORD=$4
FILECOPY1=$5
FILECOPY2=$6


sshpasses()
{
if [ ! -z "$PASSWORD" -a "$PASSWORD"!=" " ]
then
sshpass -p$PASSWORD scp $USERNAME@$HOSTNAME:$FILECOPY1 $FILECOPY2
result=$?
if [ $result -eq 0 ]
then
echo "sshpass failed"
return 0
else
return 1
fi
else
return 1
fi

}

scps()
{

scp $USERNAME@$HOSTNAME:$FILECOPY1 $FILECOPY2
result=$?
if [ $result -ne 0  ]
then
sshpasses
else
return 0
fi

}

expect_password() {
    /usr/bin/expect -c "\
    set result_code 2
	set timeout 10
    set env(TERM)
    spawn $1
    expect \"password:\"
    send \"$PASSWORD\r\"
    expect {
	timeout { 
	send_user \"Login failed. Connection failed.\"
	exit 1
	}
		eof
		
		
	}
	catch wait reason
	exit [lindex \$reason 3]
	
	
 "
  
  
  
}

expects()
{
if [ ! -z "$PASSWORD" -a "$PASSWORD"!=" " ]
then
expect_password "scp $USERNAME@$HOSTNAME:$FILECOPY1 $FILECOPY2"
result=$?
return $result
else
return 2
fi

}




expects1()
{
if [ ! -z "$PASSWORD" -a "$PASSWORD"!=" " ]
then
/usr/bin/expect <<EOF
set timeout 15
spawn scp $USERNAME@$HOSTNAME:$FILECOPY1 $FILECOPY2
expect {           
    "password:" {
        send "password\r"
    } "yes/no)?" {
        send "yes\r"
        set timeout -1
    } timeout {
        exit
    } -re . {
        exp_continue
    } eof {
        exit
    }
}
lassign [wait] pid spawnid os_error_flag value
foreach {pid spawnid os_error_flag value} [wait] break

 if {$os_error_flag == 0} {
     puts "exit status: $value"
     exit $value
 } else {
     puts "errno: $value"
     exit $value
 }
EOF
result=$?
echo "exit_status is"


echo "result is" $result
return $result
else
return 1
fi
}

connect(){
ssh $USERNAME@$HOSTNAME
result=$?
echo $result
}  

error_exit()
{
	echo "Cannot connect to cluster" 
	exit 1
}

copy(){

if [ ! -z "$PASSWORD" -a "$PASSWORD"!=" " ]
then
sshpasses
else
scps
fi
#expects
result=$?
if [[ $result -eq 0 ]]
then
echo "success"
exit 0
else
expects
result=$?
if [[ $result -eq 0 ]]
then
echo "success"
exit 0
else
if [[ $result -eq 1 ]]
then
echo "error connection expect , file location or ssh details not correct"
error_exit
else
scps
result=$?
if [[ $result -eq 0 ]]
then
exit 0
else
error_exit
fi
fi
fi
fi



}  



if [ "$CONNECTORCOPY" = "connect" ] 
then
connect
elif [ "$CONNECTORCOPY" = "copy" ]
then
copy
else
error_exit
fi

